package examen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Escuela {
    private ArrayList<Curso> lista_cursos;

    // Constructor y otros métodos

    public Escuela(){
        this.lista_cursos=new ArrayList<>();
    }

    public void insertarCurso(String nombre, String modalidad,int matriculados,double precio) {
        // Mejorar método
        Curso nuevo = new Curso(nombre, modalidad, matriculados,precio);
        this.lista_cursos.add(nuevo);
    }

    public String visualizarCursos() {
        String res = "";

        if (this.lista_cursos.isEmpty()) {
            res = "No hay cursos";
        } else {
            for (Curso c : this.lista_cursos) {
                res += c.toString();
            }
        }

        return res;
    }


    public void guardarTexto(String ruta) {

    }

    public void cargarTexto(String ruta) {

    }

    public void guardarBinario(String ruta) {

    }

    public void cargarBinario(String ruta) {

    }

    public String cursosOnline() {


        return "nada";
    }

    public String resumenAlumnos() {

        return "nada";
    }

    public void backupXML(String rutaArchivo) {


    }
}
